Graphics project for CSC8502 module, a first introduction into OpenGL programming. A lot of the files were provided as an initial codebase via a series of tutorials. Most of my work is in Renderer.cpp and SceneNodeVariants.cpp as well as various bits of code among other files

Setup:
 - Set nclgl as dependency of Main Project
 - Set Main Project as startup project
