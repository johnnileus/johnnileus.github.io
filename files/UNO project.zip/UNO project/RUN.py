import os
import time
os.startfile('sevrer.py')
time.sleep(2)
for i in range(4):
    os.startfile('client.py')
