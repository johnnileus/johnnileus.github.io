import socket
import random
from _thread import *
import pickle

IP = '192.168.1.226'
PORT = 6973

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.bind((IP, PORT))
s.listen()

#card list of only numbered cards
cards = ['R0', 'R1', 'R1', 'R2', 'R2', 'R3', 'R3', 'R4', 'R4', 'R5',
         'R5', 'R6', 'R6', 'R7', 'R7', 'R8', 'R8','R9', 'R9',
         'Y0', 'Y1', 'Y1', 'Y2', 'Y2', 'Y3', 'Y3', 'Y4', 'Y4', 'Y5',
         'Y5', 'Y6', 'Y6', 'Y7', 'Y7', 'Y8', 'Y8','Y9', 'Y9',
         'G0', 'G1', 'G1', 'G2', 'G2', 'G3', 'G3', 'G4', 'G4', 'G5',
         'G5', 'G6', 'G6', 'G7', 'G7', 'G8', 'G8','G9', 'G9',
         'B0', 'B1', 'B1', 'B2', 'B2', 'B3', 'B3', 'B4', 'B4', 'B5',
         'B5', 'B6', 'B6', 'B7', 'B7', 'B8', 'B8','B9', 'B9']
clients = []
games = []
class Game(object):
    def __init__(self, players):
        self.curTurn = 0
        self.gameReady = False
        self.cardCounts = [7,7,7,7]
        self.topCard = cards[random.randint(0,75)]
        
        self.direction = True  # true = clockwise/down
        self.totalPlayers = players
        self.currentPlayers = 0
        self.pickupUsed = False
        self.gameClients = []
    def sendGame(self, conn):

        msg = []
        msg.append(self.curTurn)    
        msg.append(self.gameReady)
        msg.append(self.cardCounts)
        msg.append(self.direction)
        msg.append(self.topCard)
        msg.append(self.pickupUsed)

        conn.send(pickle.dumps(msg))
    def nextTurn(self):
        if self.direction:
            self.curTurn += 1
        else:
            self.curTurn -= 1
    def checkIfReady(self):
        print(self.currentPlayers, self.totalPlayers)
        if self.currentPlayers == self.totalPlayers:
            self.gameReady = True
            return True
            
games.append(Game(4))

def threaded_client(conn, addr, gameID):
    game = games[gameID]
    games[gameID].gameClients.append(conn)
    games[gameID].currentPlayers += 1
    
    if games[gameID].checkIfReady():
        for i in range(len(game.gameClients)):
            games[gameID].gameClients[i].send(bytes('{}'.format(i), 'utf-8'))
            
    else:
        pass
    while True:

        try:
            
            data = conn.recv(1024).decode()
            #print('data:', data)
            if not data:
                break
            
            if data == 'GET': # get game data
                games[gameID].sendGame(conn)
            else:
                print(data)
                if data[0:2] == 'NC': # newcard (client gets new card)
                    games[gameID].cardCounts[int(data[2])] += int(data[3])
                    if data[4] == '1':
                        games[gameID].nextTurn()
                if data[0:2] == 'SC': # sendcard (client sends card)
                    print(data[3:])
                    games[gameID].cardCounts[int(data[2])] -= 1
                    game.topCard = data[3:]
                    if data[4] == 'R':
                        game.direction = not game.direction
                    if data[4] == 'B':
                        game.pickupUsed = False
                        games[gameID].nextTurn()
                        print('skipped turn from block card')
                    if data[4] == 'D':
                        game.pickupUsed = False
                        games[gameID].nextTurn()
                        print('skipped turn from draw card')
                    games[gameID].nextTurn()
                if data[0:2] == 'UP': # updatepickup ()
                    game.pickupUsed = True
                if data[0:2] == 'UC': #updatecard (updates card counts)
                    
                    print(data)
                    print(games[gameID].cardCounts)
                    games[gameID].cardCounts[int(data[2])] = int(data[3:])
                
        except Exception as e:
            print(e)
            break
    print('connection with {} lost'.format(addr))
    game.currentPlayers -= 1

print('server ready')
while True:
    clientsocket, address = s.accept()
    print('connection from {} made'.format(address))


    clients.append(clientsocket)

    start_new_thread(threaded_client, (clientsocket, address, 0))
