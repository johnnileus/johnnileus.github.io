import socket
import pickle
from _thread import *

import pygame
import random
import time

pygame.init()

#colours
textColour = [255,255,255]

cardColours = {'R' : [255,0,0], 'Y' : [255,255,0], 'G': [0,255,0], 'B': [0,0,255]}


cardOrder = {'R' : '0', 'Y' : '1', 'G' : '2', 'B' : '3', 'W' : '4'}
reverseCardOrder = {'0' : 'R', '1' : 'Y', '2' : 'G', '3' : 'B', '4' : 'W'}




plrListFont = pygame.font.SysFont('comicsansms', 30)
#'ColourNumber', ColourD = draw 2, ColourB = Block, ColourR = Reverse, WW = wild, WD = draw 4
cards = ['R0', 'R1', 'R1', 'R2', 'R2', 'R3', 'R3', 'R4',
         'R4', 'R5', 'R5', 'R6', 'R6', 'R7', 'R7', 'R8', 'R8',
         'R9', 'R9', 'RB', 'RB', 'RR', 'RR', 'RD', 'RD',
         'Y0', 'Y1', 'Y1', 'Y2', 'Y2', 'Y3', 'Y3', 'Y4',
         'Y4', 'Y5', 'Y5', 'Y6', 'Y6', 'Y7', 'Y7', 'Y8', 'Y8',
         'Y9', 'Y9', 'YB', 'YB', 'YR', 'YR', 'YD', 'YD',
         'G0', 'G1', 'G1', 'G2', 'G2', 'G3', 'G3', 'G4',
         'G4', 'G5', 'G5', 'G6', 'G6', 'G7', 'G7', 'G8', 'G8',
         'G9', 'G9', 'GB', 'GB', 'GR', 'GR', 'GD', 'GD',
         'B0', 'B1', 'B1', 'B2', 'B2', 'B3', 'B3', 'B4',
         'B4', 'B5', 'B5', 'B6', 'B6', 'B7', 'B7', 'B8', 'B8',
         'B9', 'B9', 'BB', 'BB', 'BR', 'BR', 'BD', 'BD',
         'WW', 'WW', 'WW', 'WW', 'WD', 'WD', 'WD', 'WD']


#images


playerListImg = pygame.image.load('assets/playerList.png')
curPlayerDotImg = pygame.image.load('assets/curPlayerDot.png')
directionUpImg = pygame.image.load('assets/directionUp.png')
directionDownImg = pygame.image.load('assets/directionDown.png')

winMessageImg = pygame.image.load('assets/winMessage.png')
loseMessageImg = pygame.image.load('assets/loseMessage.png')

#https://www.pinterest.co.uk/pin/388998486555952304/
gameBackgroundImg = pygame.image.load('assets/gameBackground.png')

#https://bubble-gum-simulator.fandom.com/wiki/User_blog:LukenbugWasTaken/I_tried_to_make_a_pet_thing
cardPileImg = pygame.image.load('assets/cardPile.png')
cardDeckImg = pygame.image.load('assets/cardDeck.png')

#https://worksheets.site/uno-cards-deck.html
cardZeroImg = pygame.image.load('assets/cardZero.png')
cardOneImg = pygame.image.load('assets/cardOne.png')
cardTwoImg = pygame.image.load('assets/cardTwo.png')
cardThreeImg = pygame.image.load('assets/cardThree.png')
cardFourImg = pygame.image.load('assets/cardFour.png')
cardFiveImg = pygame.image.load('assets/cardFive.png')
cardSixImg = pygame.image.load('assets/cardSix.png')
cardSevenImg = pygame.image.load('assets/cardSeven.png')
cardEightImg = pygame.image.load('assets/cardEight.png')
cardNineImg = pygame.image.load('assets/cardNine.png')
cardBlockImg = pygame.image.load('assets/cardBlock.png')
cardReverseImg = pygame.image.load('assets/cardReverse.png')
cardDrawTwoImg = pygame.image.load('assets/cardDrawTwo.png')
cardDrawFourImg = pygame.image.load('assets/cardDrawFour.png')
cardWildImg = pygame.image.load('assets/cardWild.png')

cardRedImg = pygame.image.load('assets/cardRed.png')
cardYellowImg = pygame.image.load('assets/cardYellow.png')
cardGreenImg = pygame.image.load('assets/cardGreen.png')
cardBlueImg = pygame.image.load('assets/cardBlue.png')
cardBlackImg = pygame.image.load('assets/cardBlack.png')
cardTransImg = pygame.image.load('assets/cardTrans.png')

cardForegroundImgs = {'0':cardZeroImg,'1':cardOneImg,'2':cardTwoImg,'3':cardThreeImg,
                      '4':cardFourImg,'5':cardFiveImg,'6':cardSixImg,'7':cardSevenImg,
                      '8':cardEightImg,'9':cardNineImg,'B':cardBlockImg,'R':cardReverseImg,
                      'D':cardDrawTwoImg,'F':cardDrawFourImg,'W':cardWildImg}

cardBackgroundImgs = {'R':cardRedImg,'Y':cardYellowImg,'G':cardGreenImg,
                      'B':cardBlueImg,'W':cardBlackImg}

screensize = [720,800]
framerate = 60
win = pygame.display.set_mode(screensize)
pygame.display.set_caption('aaaaaaaaa')
clock = pygame.time.Clock()
backgroundColour = (76,0,8)

class Game(object):
    def __init__(self):
        self.cardCounts = [7,7,7,7] # location of the card counters for each player
        self.curTurn = 0
        self.playerNum = 0
        self.plrCards = []
        self.direction = True # true = clockwise/down
        self.topCard = ''
        
        for i in range(7): # creates a deck of 7 cards
            self.plrCards.append(cards[random.randint(0,107)])

        self.orderCards(self.plrCards)
        print(self.plrCards)
        self.currentSelected = 0
        self.gameReady = False
        self.pickupUsed = False
        self.drawColourSelect = False
        self.gameWon = False
    def addCard(self, amount, pickedUp):
        for i in range(amount): #adds x amount of cards to the player's deck
            self.plrCards.append(cards[random.randint(0,107)])
        self.plrCards = self.orderCards(self.plrCards)
        self.cardCounts[self.playerNum] += amount #add to counter
        self.nextTurn()
        if pickedUp: #if pickedUp is true then it sends the message with a 1 on the end
            s.send(bytes('NC{}{}1'.format(self.playerNum, amount), 'utf-8'))
        else:
            s.send(bytes('NC{}{}0'.format(self.playerNum, amount), 'utf-8'))
    def sendCard(self, index, wildCard, colour):
        
        self.cardCounts[self.playerNum] -= 1 # remove 1 from player's cardcount
        if not wildCard:
            
            s.send(bytes('SC{}{}'.format(self.playerNum, self.plrCards[index]), 'utf-8'))
            #performs the effects each 
            if self.plrCards[index][1] == 'R': # if reverse
                game.direction = not game.direction
            if self.plrCards[index][1] == 'B': # if block
                self.nextTurn()
            if self.plrCards[index][1] == 'D': # if draw
                self.cardCounts[self.findNextTurn(1)%4] += 2
                self.nextTurn()
        else:
            card = self.plrCards[index]
            #appends the card's colour onto the end
            card = 'W'+card[1:]+colour
            #send the instruction to the server with the card and player's number
            s.send(bytes('SC{}{}'.format(self.playerNum, card), 'utf-8'))
            #performs the effect of wild draw 4 card
            if self.plrCards[index][1] == 'D': # if draw
                self.cardCounts[self.findNextTurn(1)%4] += 4
                self.nextTurn()
        self.nextTurn()
        del self.plrCards[index]
    def orderCards(self, arr): # https://www.geeksforgeeks.org/python-program-for-insertion-sort/
        #turns the first character into a number
        for i in range(len(arr)):
            arr[i] = cardOrder[arr[i][0]] + arr[i][1:]
          
        
        #insertion sort for cards
        for i in range(1, len(arr)): 
      
            key = arr[i] 
      
            j = i-1
            while j >=0 and key < arr[j] : 
                    arr[j+1] = arr[j] 
                    j -= 1
            arr[j+1] = key
        #convert back to letters
        for i in range(len(arr)):
            arr[i] = reverseCardOrder[arr[i][0]] + arr[i][1:]
        return arr
    def findNextTurn(self, amount): # return the next turn
        if self.direction:
            newTurn = self.curTurn + amount
        else:
            newTurn = self.curTurn - amount
        return newTurn
    def nextTurn(self): # put next turn into curTurn
        if self.direction:
            self.curTurn += 1
        else:
            self.curTurn -= 1
    def checkIfCardMatches(self, card):
        if card[0] == 'W': # if wildcard
            return True
        #if centercard is wildcard and input card's colour is the same as centercard's colour
        elif self.topCard[0] == 'W' and self.topCard[2] == card[0]: 
            return True
        #if the colours or the numbers match
        elif card[0] == self.topCard[0] or card[1] == self.topCard[1]:
            if len(self.topCard) == 2:
                return True
            elif card[1] == 'D' and self.topCard[2] == card[0]:
                return True
        else:
            return False
    def drawCard(self, x, y, colour, number, playable):
        
        if colour == 'W' and number == 'D': # if the card is a wild draw 4 card
            number = 'F' # this is the code for the image wild draw 4
        cardBackgroundImg = cardBackgroundImgs[colour]
        cardForegroundImg = cardForegroundImgs[number]

        win.blit(cardBackgroundImg, [x, y])
        win.blit(cardForegroundImg, [x, y])
        if not playable: # draw transparent black card over the top
            win.blit(cardTransImg, [x, y])
    def getCardGap(self): #gap between cards in the deck
        cardNum = len(self.plrCards)
        try:
            W = (screensize[0] - 40 - 126) / (cardNum - 1)
        except:
            W = (screensize[0] + 126) / 2
        return W
    def draw(self, mx, my):
        win.blit(gameBackgroundImg, [0,0]) # draw the background

        if self.gameReady:
            # player list
            win.blit(playerListImg, [20,20])
            win.blit(curPlayerDotImg, [20, 20 + 51*(self.curTurn%4)])
            for i in range(len(self.cardCounts)): # loops over all the card counts
                if i == self.playerNum:
                    text = plrListFont.render('Player (You): {} cards'.format(self.cardCounts[i]),True, textColour)
                else:
                    text = plrListFont.render('Player {}: {} cards'.format(i+1,self.cardCounts[i]),True, textColour)
                win.blit(text, [80, 51*i + 30])
            if self.direction: # draw arrow pointing which direction next turn goes
                win.blit(directionDownImg, [37,102])
            else:
                win.blit(directionUpImg, [37,102])

            #log
            #pygame.draw.rect(win, [117,0,10], [420, 20, 280, 230])

            #card pile
            win.blit(cardPileImg, [65, 275])
            if self.topCard != '':
                if self.topCard[0] == 'W':
                    col = self.topCard[2]
                    num = 'F'
                else:
                    col = self.topCard[0]
                    num = self.topCard[1]
                self.drawCard(147, 305, col, num, True)

            #colour picker
            if self.drawColourSelect:
                pygame.draw.rect(win, cardColours['R'], [20,270,107,135])
                pygame.draw.rect(win, cardColours['Y'], [293,270,107,135])
                pygame.draw.rect(win, cardColours['G'], [20,425,107,135])
                pygame.draw.rect(win, cardColours['B'], [293,425,107,135])
            
            #pickup card
            win.blit(cardDeckImg, [420,270])
            
            # deck
            W = game.getCardGap()
            cardPos = int((mx - 20) // W)
            cardLen = len(self.plrCards) - 1
            for i in range(len(self.plrCards)):
                card = self.plrCards[i]
                
                #check if mouse is hovering over card
                if not self.drawColourSelect:
                    if cardPos > cardLen:
                        cardPos = cardLen
                    if cardPos < 0:
                        cardPos = 0
                    self.currentSelected = cardPos

                #find x and y pos
                x = int(W*i + 20)
                if i == cardPos and my > 570:
                    y = 480
                else:
                    y = 580

                if self.checkIfCardMatches(card):
                    playable = True
                else:
                    playable = False
                
                self.drawCard(x, y, card[0], card[1], playable)
    
        else:
            text = cardFont.render('Waiting for players', True, [255,0,0])
            win.blit(text, [-50,100])
        
    def process(self, mx, my):
        
        self.draw(mx, my)
class Button(object):
    def __init__(self, x, y, w, h):
        self.x = x
        self.y = y
        self.w = w
        self.h = h
    def checkIfInside(self, mx, my):
        if mx > self.x and mx < self.x + self.w and my > self.y and my < self.y + self.h:
            return True
        else:
            return False

    

pickUpCardBtn = Button(420,270,280,290)
cardDeckBtn = Button(20,580,680,200)

redBtn = Button(20, 270, 107, 135)
yellowBtn = Button(293, 270, 107, 135)
greenBtn = Button(20, 425, 107, 135)
blueBtn = Button(293, 425, 107, 135)


game = Game()

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.connect((socket.gethostname(), 6973))

msg = s.recv(1024).decode('utf-8')
print(msg)
game.playerNum = int(msg)
game.gameReady = True
s.send(bytes('UC{}{}'.format(game.playerNum, len(game.plrCards)), 'utf-8'))

run = True
while run:
    s.send(bytes('GET', 'utf-8'))
    reply = pickle.loads(s.recv(1024))
    game.pickupUsed = reply[5]
    if game.curTurn != reply[0]:
        if game.playerNum == game.findNextTurn(1)%4:
            if reply[4][1] == 'D' and not game.pickupUsed:
                if reply[4][0] != 'W':
                    game.addCard(2, False)
                    print('gained 2 cards')
                else:
                    game.addCard(4, False)
                    print('gained 4 cards')
                game.pickupUsed = True
                s.send(bytes('UP','utf-8'))
    game.curTurn = reply[0]
    game.cardCounts = reply[2]
    game.direction = reply[3]
    game.topCard = reply[4]

    ct = clock.tick(framerate)

    mx, my = pygame.mouse.get_pos()
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False
        
        if event.type == pygame.MOUSEBUTTONDOWN:
            
            if pygame.mouse.get_pressed()[0]:
                if pickUpCardBtn.checkIfInside(mx, my):
                    if game.playerNum == game.curTurn%4:
                        game.addCard(1, True)
                elif cardDeckBtn.checkIfInside(mx, my):
                    if game.curTurn%4 == game.playerNum:
                        if game.checkIfCardMatches(game.plrCards[game.currentSelected]):
                            if game.plrCards[game.currentSelected][0] == 'W':
                                game.drawColourSelect = True 
                            else:
                                game.sendCard(game.currentSelected, False, '')
                elif redBtn.checkIfInside(mx, my):
                    game.sendCard(game.currentSelected, True, 'R')
                    game.drawColourSelect = False
                elif yellowBtn.checkIfInside(mx, my):
                    game.sendCard(game.currentSelected, True, 'Y')
                    game.drawColourSelect = False
                elif greenBtn.checkIfInside(mx, my):
                    game.sendCard(game.currentSelected, True, 'G')
                    game.drawColourSelect = False
                elif blueBtn.checkIfInside(mx, my):
                    game.sendCard(game.currentSelected, True, 'B')
                    game.drawColourSelect = False
                    
    game.process(mx, my)
    
    pygame.display.update()
pygame.quit()
